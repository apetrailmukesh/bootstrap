<?php

class Location extends Eloquent {

	protected $table = 'location';
	public $timestamps = false;
}
