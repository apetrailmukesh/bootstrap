<?php

class SavedCar extends Eloquent {

	protected $table = 'saved_car';
	public $timestamps = false;
}
