<?php

class Interior extends Eloquent {

	protected $table = 'interior';
	public $timestamps = false;
}
