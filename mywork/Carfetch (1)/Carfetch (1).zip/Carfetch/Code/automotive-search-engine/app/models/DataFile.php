<?php

class DataFile extends Eloquent {

	protected $table = 'data_file';
	public $timestamps = false;
}
