<?php

class Transmission extends Eloquent {

	protected $table = 'transmission';
	public $timestamps = false;
}
