<?php

class Drive extends Eloquent {

	protected $table = 'drive';
	public $timestamps = false;
}
