<?php

class Exterior extends Eloquent {

	protected $table = 'exterior';
	public $timestamps = false;
}
