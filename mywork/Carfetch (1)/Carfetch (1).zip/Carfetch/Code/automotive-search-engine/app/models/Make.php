<?php

class Make extends Eloquent {

	protected $table = 'make';
	public $timestamps = false;
}
