<?php

class Dealer extends Eloquent {

	protected $table = 'dealer';
	public $timestamps = false;
}
