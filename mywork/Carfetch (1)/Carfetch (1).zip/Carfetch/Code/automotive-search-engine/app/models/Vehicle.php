<?php

class Vehicle extends Eloquent {

	protected $table = 'vehicle';
	public $timestamps = true;
}
