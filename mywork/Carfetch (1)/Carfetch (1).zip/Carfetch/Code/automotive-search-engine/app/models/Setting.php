<?php

class Setting extends Eloquent {

	protected $table = 'setting';
	public $timestamps = false;
}
