<?php

class SavedSearch extends Eloquent {

	protected $table = 'saved_search';
	public $timestamps = false;
}
