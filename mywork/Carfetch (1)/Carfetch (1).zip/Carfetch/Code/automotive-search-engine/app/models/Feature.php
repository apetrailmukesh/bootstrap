<?php

class Feature extends Eloquent {

	protected $table = 'feature';
	public $timestamps = false;
}
