<?php

class Body extends Eloquent {

	protected $table = 'body';
	public $timestamps = false;
}
