<?php

class Fuel extends Eloquent {

	protected $table = 'fuel';
	public $timestamps = false;
}
