<?php

class SearchSuggestion extends Eloquent {

	protected $table = 'search_suggestion';
	public $timestamps = false;
}
