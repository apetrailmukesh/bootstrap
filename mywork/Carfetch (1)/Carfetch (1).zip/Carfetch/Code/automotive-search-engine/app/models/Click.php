<?php

class Click extends Eloquent {

	protected $table = 'click';
	public $timestamps = false;
}
