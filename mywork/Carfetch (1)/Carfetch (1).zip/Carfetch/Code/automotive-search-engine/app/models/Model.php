<?php

class Model extends Eloquent {

	protected $table = 'model';
	public $timestamps = false;
}
