<?php

class DealerHistory extends Eloquent {

	protected $table = 'dealer_history';
	public $timestamps = false;
}
