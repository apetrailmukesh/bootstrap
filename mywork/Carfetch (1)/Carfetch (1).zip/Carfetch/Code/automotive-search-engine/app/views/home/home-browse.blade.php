<div class="row">
	<div class="small-12 small-centered text-center column">
		<p class="search-options">
			{{ HTML::linkRoute('get.advanced', 'Advanced Search') }}
			{{ HTML::linkRoute('get.browse.make', 'Browse by Make') }}
			{{ HTML::linkRoute('get.browse.body', 'Browse by Body Style') }}
			{{ HTML::linkRoute('get.browse.state', 'Browse by Location') }}
		</p>
	</div>
</div>