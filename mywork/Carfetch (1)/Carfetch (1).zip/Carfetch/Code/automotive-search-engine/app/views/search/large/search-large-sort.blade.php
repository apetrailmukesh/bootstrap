<div class="medium-4 large-3 columns">
	<div class="hide-for-small">
		<form>
			<div class="row">
				<div class="small-4 columns">
					<label for="sort" class="right inline">Sort by</label>
				</div>
				<div class="small-8 columns no-left-pad">
					<select id="large-sort" class="small">
						<option value="price-1" selected>Price - Highest</option>
						<option value="price-0">Price - Lowest</option>
						<option value="mileage-1">Mileage - Highest</option>
						<option value="mileage-0">Mileage - Lowest</option>
						<option value="year-1">Year - Newest</option>
						<option value="year-0">Year - Oldest</option>
					</select>
				</div>
			</div>
		</form>
	</div>
</div>