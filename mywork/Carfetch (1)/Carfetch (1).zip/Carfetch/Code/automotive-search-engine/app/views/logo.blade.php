<header>
	<div class="row">
		<div class="small-12 small-centered text-center column">
			<h1 class="logo">
				<span>car</span><span>fetch</span><span>.com</span>
			</h1>
			<p class="tagline secondary-text">Search new &amp; used cars for sale.</p>
		</div>
	</div>
</header>