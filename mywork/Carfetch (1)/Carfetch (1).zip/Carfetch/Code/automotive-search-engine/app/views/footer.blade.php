<footer>
	<div class="row">
		<div class="small-12 small-centered text-center column">
			<span>&copy; 2015 carfetch.com</span>
			<span>
				<a href="#">Terms of Use</a><a href="#">Privacy Policy</a><a href="#">Site Map</a>
			</span>
		</div>
	</div>
</footer>